#!/usr/bin/env python3
"""Actor-only SPI finetuning from a pretrained 1M checkpoint.

Loads a pretrained mini-run directory (e.g. ``checkpoints/1m_env_best/ct_cube-triple``),
**freezes** dynamics / subgoal generator / IDM / critic (and target nets), and trains
**only** the SPI actor against the frozen critic scorer + frozen dynamics/IDM proposals.

Flow: load checkpoint -> freeze non-actor -> actor-only SPI update -> eval/save.

The SPI actor loss (see ``agents/actor.ActorAgent.actor_loss``) already implements::

    L = E[ -Q(s, a_actor, g) / mean|Q|  +  (1 / (2 * spi_tau)) * sum_k rho_k * ||a_actor - a_prop_k||^2 ]

where ``rho`` is a softmax over the frozen dynamics/IDM proposal critic scores. The proximity
term ``D`` is the deterministic squared-L2 distance to the (frozen) IDM/dynamics action chunks.

Freeze guarantee: this script never calls ``dynamics_agent.update`` or ``critic_agent.update``;
the jitted ``actor_agent.update`` only touches the actor ``TrainState``. A param-diff check
(``utils.freeze_check``) asserts actor params moved while critic/dynamics stayed identical.

Example (single tau)::

    MUJOCO_GL=egl python train_actor_spi.py \
        --env_name=cube-triple-play-v0 --spi_tau=1.0 --seed=0 \
        --actor_spi_steps=50000 --actor_spi_lr=3e-4

Smoke test (2 steps, fast)::

    MUJOCO_GL=egl python train_actor_spi.py --env_name=cube-double-play-v0 --debug_num_steps=2
"""

from __future__ import annotations

import json
import os
import shutil
import sys
import time
from pathlib import Path
from typing import Any

import jax
import numpy as np
import optax
import yaml
from absl import app, flags

# Importing main registers all of its absl flags and shared training helpers.
import main as M  # noqa: F401  (side effect: flag registration)
from main import (
    FLAGS,
    _build_actor_batch_from_dynamics,
    _create_actor_agent,
    _create_critic_agent,
    _evaluate_env_tasks,
    _intersect_valid_starts,
    _make_critic_dataset,
    _rescore_actor_batch_for_update,
    _sample_shared_idxs,
)
from eval_checkpoint import _build_configs
from agents.dynamics import DynamicsAgent
from utils.datasets import Dataset, PathHGCDataset
from utils.env_utils import make_env_and_datasets
from utils.eval_results_io import save_eval_results
from utils.flax_utils import TrainState, restore_agent, save_agent
from utils.freeze_check import assert_frozen, assert_trained, summarize_param_diff
from utils.goal_representation import infer_phi_goal_obs_indices, normalize_phi_goal_obs_indices
from utils.log_utils import CsvLogger
from utils.run_io import (
    list_checkpoint_suffixes,
    parse_int_list,
    pick_epoch,
    resolve_actor_checkpoint_dir,
    resolve_critic_checkpoint_dir,
    resolve_dynamics_checkpoint_dir,
)

import jax.numpy as jnp


_REPO = Path(__file__).resolve().parent
_DEFAULT_BEST_ROOT = _REPO / 'checkpoints' / '1m_env_best'


# --- actor-SPI-specific flags (new names only; reuse main's seed/env_name/eval_* flags) ---
flags.DEFINE_string('pretrained_ckpt_dir', '', 'Pretrained mini-run dir. Empty -> auto-resolve from env_name.')
flags.DEFINE_integer('pretrained_epoch', -1, 'Checkpoint suffix to load; -1 = latest available.')
flags.DEFINE_integer('actor_spi_steps', 50000, 'Number of actor SPI gradient steps.')
flags.DEFINE_float('actor_spi_lr', 3e-4, 'Adam learning rate for the actor SPI optimizer.')
flags.DEFINE_float('spi_tau', -1.0, 'Override actor SPI tau; < 0 keeps the checkpoint value.')
flags.DEFINE_integer('actor_spi_batch_size', 0, 'Batch size for actor SPI; 0 = use checkpoint batch_size.')
flags.DEFINE_integer('eval_interval', 0, 'Eval every N actor SPI steps; 0 disables intermediate eval.')
flags.DEFINE_integer('save_interval', 0, 'Save actor every N steps; 0 = only save at the end.')
flags.DEFINE_boolean('freeze_non_actor', True, 'Freeze dynamics/IDM/subgoal/critic; only train the actor.')
flags.DEFINE_boolean('reset_actor_optimizer', True, 'Reinitialize the actor optimizer (Adam) for finetuning.')
flags.DEFINE_integer('debug_num_steps', 0, 'If > 0, run only this many steps (smoke test) and force a freeze check.')
flags.DEFINE_string('actor_spi_out_root', 'checkpoints/actor_spi', 'Root dir for actor SPI outputs.')
flags.DEFINE_integer('actor_spi_eval_episodes', 25, 'Episodes per task for actor SPI eval.')
flags.DEFINE_integer('actor_spi_log_interval', 500, 'Log every N steps.')
flags.DEFINE_string('mujoco_gl', '', 'Optional MuJoCo GL backend (e.g. egl).')
flags.DEFINE_string('actor_spi_config', '', 'Optional YAML that sets the flags above (CLI args still win).')


def _argv_sets_flag(name: str) -> bool:
    dashed = name.replace('_', '-')
    for arg in sys.argv[1:]:
        if arg.startswith(f'--{name}=') or arg.startswith(f'--{dashed}='):
            return True
        if arg in (f'--{name}', f'--{dashed}', f'--no{name}', f'--no{dashed}'):
            return True
    return False


def _apply_config_yaml(path: str) -> None:
    """Set flags from a YAML config unless they were explicitly passed on argv."""
    if not path:
        return
    with open(path, encoding='utf-8') as f:
        data = yaml.safe_load(f) or {}
    for key, value in data.items():
        if not hasattr(FLAGS, key):
            raise ValueError(f'Unknown actor_spi_config key: {key!r}')
        if _argv_sets_flag(key):
            continue
        setattr(FLAGS, key, value)


def _resolve_pretrained_dir(env_name: str, explicit: str) -> tuple[str, Path]:
    """Return ``(resolved_env_name, ckpt_dir)``.

    Accepts an explicit dir, or auto-resolves from env_name (full like
    ``cube-triple-play-v0`` or short like ``cube-triple``) via the 1m_env_best manifest,
    falling back to scanning sub-dirs' flags.json.
    """
    if explicit:
        d = Path(explicit)
        if not d.is_dir():
            raise FileNotFoundError(f'pretrained_ckpt_dir not found: {d}')
        resolved_env = env_name
        flags_path = d / 'flags.json'
        if flags_path.is_file():
            with open(flags_path, encoding='utf-8') as f:
                fg = json.load(f).get('flags', {})
            resolved_env = fg.get('env_name', env_name)
        return resolved_env, d

    manifest_path = _DEFAULT_BEST_ROOT / 'manifest.yaml'
    if manifest_path.is_file():
        manifest = yaml.safe_load(manifest_path.read_text(encoding='utf-8')) or {}
        for entry in manifest.get('envs', []):
            if env_name in (entry.get('env'), entry.get('env_short')):
                dest = _REPO / entry['dest_dir']
                if dest.is_dir():
                    return str(entry.get('env', env_name)), dest

    # Fallback: scan sub-dirs for a flags.json with a matching env_name / env_short.
    if _DEFAULT_BEST_ROOT.is_dir():
        for sub in sorted(_DEFAULT_BEST_ROOT.iterdir()):
            if not sub.is_dir():
                continue
            flags_path = sub / 'flags.json'
            if not flags_path.is_file():
                continue
            with open(flags_path, encoding='utf-8') as f:
                fg = json.load(f).get('flags', {})
            sub_env = str(fg.get('env_name', ''))
            if env_name == sub_env or sub.name.endswith(env_name):
                return sub_env or env_name, sub
    raise FileNotFoundError(
        f'Could not resolve a pretrained checkpoint dir for env_name={env_name!r}. '
        f'Pass --pretrained_ckpt_dir explicitly (looked under {_DEFAULT_BEST_ROOT}).'
    )


def _format_tau_tag(tau: float) -> str:
    s = ('%g' % float(tau))
    return s


def _to_floats(info: dict[str, Any]) -> dict[str, float]:
    out = {}
    for k, v in info.items():
        try:
            out[k] = float(np.asarray(v))
        except (TypeError, ValueError):
            continue
    return out


def main(_):
    _apply_config_yaml(FLAGS.actor_spi_config)

    if str(FLAGS.mujoco_gl).strip():
        from rollout.env import configure_mujoco_gl

        configure_mujoco_gl(str(FLAGS.mujoco_gl))

    seed = int(FLAGS.seed)
    env_name_in = str(FLAGS.env_name)
    resolved_env, ckpt_dir = _resolve_pretrained_dir(env_name_in, str(FLAGS.pretrained_ckpt_dir).strip())
    # Downstream config (phi indices / env eval) keys off FLAGS.env_name.
    FLAGS.env_name = resolved_env

    flags_path = ckpt_dir / 'flags.json'
    if not flags_path.is_file():
        raise FileNotFoundError(flags_path)
    with open(flags_path, encoding='utf-8') as f:
        root = json.load(f)
    fg = root['flags']

    # Match the proposal-building behaviour used during pretraining.
    FLAGS.plan_candidates = int(fg.get('plan_candidates', 1))
    FLAGS.plan_noise_scale = float(fg.get('plan_noise_scale', 1.0))
    FLAGS.measure_timing = False

    dynamics_config, critic_config, actor_config = _build_configs(root, fg)

    # Actor SPI overrides.
    actor_config['lr'] = float(FLAGS.actor_spi_lr)
    if float(FLAGS.spi_tau) >= 0.0:
        actor_config['spi_tau'] = float(FLAGS.spi_tau)
    spi_tau = float(actor_config['spi_tau'])

    batch_size = int(FLAGS.actor_spi_batch_size) if int(FLAGS.actor_spi_batch_size) > 0 else int(fg['batch_size'])
    dynamics_config['batch_size'] = batch_size
    critic_config['batch_size'] = batch_size
    actor_config['batch_size'] = batch_size

    # --- env + datasets ---
    dataset_dir = fg.get('dataset_dir', '') or str(FLAGS.dataset_dir)
    env, train_plain, _ = make_env_and_datasets(
        resolved_env,
        frame_stack=critic_config['frame_stack'],
        dataset_dir=dataset_dir,
    )
    obs_dim_env = int(np.prod(env.observation_space.shape))
    phi_idxs = normalize_phi_goal_obs_indices(critic_config.get('phi_goal_obs_indices', ()))
    if not phi_idxs:
        phi_idxs = infer_phi_goal_obs_indices(str(resolved_env), obs_dim_env)
    critic_config['phi_goal_obs_indices'] = phi_idxs
    dynamics_config['phi_goal_obs_indices'] = phi_idxs
    action_dim = int(np.asarray(env.action_space.shape).prod())
    critic_config['action_dim'] = action_dim
    actor_config['action_dim'] = action_dim

    dynamics_dataset = PathHGCDataset(Dataset.create(**train_plain), dynamics_config)
    critic_dataset = _make_critic_dataset(train_plain, critic_config)
    common_valid_starts = _intersect_valid_starts(dynamics_dataset, critic_dataset)

    np.random.seed(seed)
    ex_idxs = _sample_shared_idxs(common_valid_starts, batch_size)
    ex_dynamics = dynamics_dataset.sample(len(ex_idxs), idxs=ex_idxs)
    ex_critic = critic_dataset.sample(len(ex_idxs), idxs=ex_idxs)

    # --- build + load agents (epoch consistent across the three) ---
    dynamics_agent = DynamicsAgent.create(
        seed, ex_dynamics['observations'], dynamics_config, ex_actions=ex_dynamics['actions']
    )
    critic_agent = _create_critic_agent(seed, ex_critic, critic_config)
    actor_agent = _create_actor_agent(seed, ex_dynamics, actor_config)

    dyn_dir = resolve_dynamics_checkpoint_dir(ckpt_dir)
    epoch = pick_epoch(int(FLAGS.pretrained_epoch), list_checkpoint_suffixes(dyn_dir))
    dynamics_agent = restore_agent(dynamics_agent, str(dyn_dir), epoch)
    critic_agent = restore_agent(critic_agent, str(resolve_critic_checkpoint_dir(ckpt_dir)), epoch)
    actor_agent = restore_agent(actor_agent, str(resolve_actor_checkpoint_dir(ckpt_dir, required=True)), epoch)

    # Reset (default) the actor optimizer for finetuning, keeping the loaded actor params.
    if bool(FLAGS.reset_actor_optimizer):
        fresh_actor = TrainState.create(
            actor_agent.actor.model_def,
            actor_agent.actor.params,
            tx=optax.adam(float(FLAGS.actor_spi_lr)),
        )
        actor_agent = actor_agent.replace(actor=fresh_actor)

    # --- output dir: checkpoints/actor_spi/{env}/tau_{tau}/seed_{seed}/ ---
    tau_tag = _format_tau_tag(spi_tau)
    out_dir = Path(FLAGS.actor_spi_out_root) / resolved_env / f'tau_{tau_tag}' / f'seed_{seed}'
    if not out_dir.is_absolute():
        out_dir = _REPO / out_dir
    actor_out_dir = out_dir / 'checkpoints' / 'actor'
    eval_out_dir = out_dir / 'eval_results'
    actor_out_dir.mkdir(parents=True, exist_ok=True)
    eval_out_dir.mkdir(parents=True, exist_ok=True)
    shutil.copy2(flags_path, out_dir / 'flags.json')
    cfg_used = ckpt_dir / 'config_used.yaml'
    if cfg_used.is_file():
        shutil.copy2(cfg_used, out_dir / 'config_used.yaml')

    total_steps = int(FLAGS.debug_num_steps) if int(FLAGS.debug_num_steps) > 0 else int(FLAGS.actor_spi_steps)
    debug_mode = int(FLAGS.debug_num_steps) > 0
    log_interval = max(1, int(FLAGS.actor_spi_log_interval))
    eval_task_ids = parse_int_list(FLAGS.eval_task_ids)
    eval_episodes = max(1, int(FLAGS.actor_spi_eval_episodes))

    print(
        f'[actor_spi] env={resolved_env} ckpt_dir={ckpt_dir} epoch={epoch} '
        f'spi_tau={spi_tau} lr={float(FLAGS.actor_spi_lr)} batch={batch_size} steps={total_steps} '
        f'freeze_non_actor={bool(FLAGS.freeze_non_actor)} reset_actor_opt={bool(FLAGS.reset_actor_optimizer)}',
        flush=True,
    )
    print(f'[actor_spi] out_dir={out_dir}', flush=True)

    # Snapshot params for the freeze / trained-diff verification.
    actor_params_before = jax.device_get(actor_agent.actor.params)
    critic_params_before = jax.device_get(critic_agent.network.params)
    dynamics_params_before = jax.device_get(dynamics_agent.network.params)

    csv_logger = CsvLogger(os.path.join(out_dir, 'train.csv'), flush_every_n=1)
    use_wandb = bool(FLAGS.use_wandb)
    if use_wandb:
        from utils.log_utils import get_exp_name, setup_wandb

        setup_wandb(
            project='OGBench',
            group=str(FLAGS.run_group),
            name=get_exp_name(seed, env_name=resolved_env, agent_name=f'actor_spi_tau{tau_tag}'),
        )
        import wandb

    def _run_eval(step: int) -> dict[str, float]:
        metrics = _evaluate_env_tasks(
            env,
            dynamics_agent,
            actor_agent,
            actor_config,
            critic_config,
            critic_agent=critic_agent,
            task_ids=eval_task_ids,
            episodes_per_task=eval_episodes,
            wandb_enabled=False,
            subgoal_override_goal=bool(FLAGS.subgoal_override_goal),
        )
        save_eval_results(
            out_dir,
            epoch=step,
            subgoal_eval_num_samples=int(dynamics_config.get('subgoal_eval_num_samples', 1)),
            task_ids=eval_task_ids,
            episodes_per_task=eval_episodes,
            metrics=metrics,
            fg=fg,
            root=root,
            subgoal_temperature=float(dynamics_config.get('subgoal_temperature', 0.0)),
        )
        return metrics

    first_time = time.time()
    for step in range(1, total_steps + 1):
        idxs = _sample_shared_idxs(common_valid_starts, batch_size)
        dynamics_batch = dynamics_dataset.sample(batch_size, idxs=idxs)

        # Build frozen dynamics/IDM proposals; this only advances dynamics rng (no param change).
        dynamics_agent, actor_batch, coupling_info, _ = _build_actor_batch_from_dynamics(
            dynamics_agent, critic_agent, dynamics_batch, actor_config
        )
        actor_batch_for_update, _ = _rescore_actor_batch_for_update(actor_batch, critic_agent, actor_config)
        # Actor-only update: jitted, touches the actor TrainState exclusively.
        actor_agent, actor_info = actor_agent.update(actor_batch_for_update, critic_agent)

        do_log = step % log_interval == 0 or step == total_steps or debug_mode
        if do_log:
            info = _to_floats(actor_info)
            metrics = {
                'actor_spi/loss': info.get('spi_actor/actor_loss', float('nan')),
                'actor_spi/q_term': info.get('spi_actor/q_term', float('nan')),
                'actor_spi/prox_term': info.get('spi_actor/prox_term', float('nan')),
                'actor_spi/spi_tau': spi_tau,
                'actor_spi/actor_action_norm': info.get('spi_actor/actor_action_norm', float('nan')),
                'actor_spi/idm_action_norm': info.get('spi_actor/idm_action_norm', float('nan')),
                'actor_spi/action_l2_to_idm': info.get('spi_actor/action_l2_to_idm', float('nan')),
                'actor_spi/step': float(step),
                'time/total_sec': time.time() - first_time,
            }
            do_eval = bool(FLAGS.eval_interval > 0 and step % int(FLAGS.eval_interval) == 0 and step != total_steps)
            if do_eval:
                eval_metrics = _run_eval(step)
                metrics['actor_spi/eval_success_rate'] = float(eval_metrics.get('eval/success_rate_mean', float('nan')))
                metrics['actor_spi/eval_idm_success_rate'] = float(
                    eval_metrics.get('eval_idm/success_rate_mean', float('nan'))
                )
            csv_logger.log(metrics, step=step)
            if use_wandb:
                wandb.log(metrics, step=step)
            print(
                f'[actor_spi] step={step}/{total_steps} loss={metrics["actor_spi/loss"]:.4f} '
                f'q_term={metrics["actor_spi/q_term"]:.4f} prox_term={metrics["actor_spi/prox_term"]:.4f} '
                f'a_norm={metrics["actor_spi/actor_action_norm"]:.3f} '
                f'idm_norm={metrics["actor_spi/idm_action_norm"]:.3f} '
                f'l2_to_idm={metrics["actor_spi/action_l2_to_idm"]:.4f}',
                flush=True,
            )

        if int(FLAGS.save_interval) > 0 and step % int(FLAGS.save_interval) == 0 and step != total_steps:
            save_agent(actor_agent, str(actor_out_dir), step)

    # --- final save ---
    save_agent(actor_agent, str(actor_out_dir), total_steps)

    # --- freeze / trained verification ---
    actor_params_after = jax.device_get(actor_agent.actor.params)
    critic_params_after = jax.device_get(critic_agent.network.params)
    dynamics_params_after = jax.device_get(dynamics_agent.network.params)

    actor_diff = summarize_param_diff(actor_params_before, actor_params_after)
    critic_diff = summarize_param_diff(critic_params_before, critic_params_after)
    dynamics_diff = summarize_param_diff(dynamics_params_before, dynamics_params_after)
    print(f'[actor_spi] param-diff actor={actor_diff} critic={critic_diff} dynamics={dynamics_diff}', flush=True)
    if bool(FLAGS.freeze_non_actor):
        assert_frozen(critic_params_before, critic_params_after, name='critic', tol=1e-6)
        assert_frozen(dynamics_params_before, dynamics_params_after, name='dynamics', tol=1e-6)
        assert_trained(actor_params_before, actor_params_after, name='actor', min_abs=0.0)
        print('[actor_spi] freeze check PASSED (actor moved; critic/dynamics unchanged).', flush=True)

    # --- final eval ---
    final_metrics = _run_eval(total_steps)
    print(
        f"[actor_spi] FINAL eval actor_success={final_metrics.get('eval/success_rate_mean', float('nan')):.4f} "
        f"idm_success={final_metrics.get('eval_idm/success_rate_mean', float('nan')):.4f}",
        flush=True,
    )

    meta = {
        'env': resolved_env,
        'pretrained_ckpt_dir': str(ckpt_dir.relative_to(_REPO)) if ckpt_dir.is_relative_to(_REPO) else str(ckpt_dir),
        'pretrained_epoch': int(epoch),
        'spi_tau': spi_tau,
        'actor_spi_lr': float(FLAGS.actor_spi_lr),
        'actor_spi_steps': int(total_steps),
        'actor_spi_batch_size': int(batch_size),
        'seed': seed,
        'reset_actor_optimizer': bool(FLAGS.reset_actor_optimizer),
        'freeze_non_actor': bool(FLAGS.freeze_non_actor),
        'debug_mode': bool(debug_mode),
        'actor_checkpoint': f'checkpoints/actor/params_{total_steps}.pkl',
        'param_diff': {
            'actor_max_abs': actor_diff['max_abs'],
            'critic_max_abs': critic_diff['max_abs'],
            'dynamics_max_abs': dynamics_diff['max_abs'],
        },
        'final_eval': {
            'actor_success_rate_mean': float(final_metrics.get('eval/success_rate_mean', float('nan'))),
            'idm_success_rate_mean': float(final_metrics.get('eval_idm/success_rate_mean', float('nan'))),
        },
        'frozen_modules': ['dynamics', 'subgoal_generator', 'idm', 'critic', 'value', 'target_critic'],
    }
    (out_dir / 'actor_spi_meta.yaml').write_text(
        yaml.safe_dump(meta, sort_keys=False, default_flow_style=False), encoding='utf-8'
    )
    csv_logger.close() if hasattr(csv_logger, 'close') else None
    print(f'[actor_spi] DONE. outputs in {out_dir}', flush=True)


if __name__ == '__main__':
    app.run(main)
