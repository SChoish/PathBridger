# Actor-only SPI Finetuning

Finetune **only the actor** with the SPI objective, starting from a pretrained 1M
checkpoint. Dynamics / subgoal generator / IDM / critic (and target nets) are loaded
and **frozen**; the actor is the single trainable module. Intended for sweeping
`spi_tau` to tune actor SPI performance on top of an IDM-tuned checkpoint.

Flow: **checkpoint load → freeze non-actor → actor-only SPI update → eval/save**.

## Entry point

`train_actor_spi.py` (absl flags, reuses `main.py` helpers + `eval_checkpoint._build_configs`).

It never calls `dynamics_agent.update` or `critic_agent.update`; the jitted
`ActorAgent.update` only touches the actor `TrainState`. A param-diff check
(`utils/freeze_check.py`) asserts after training that the actor moved while
critic/dynamics stayed numerically identical (tolerance `1e-6`).

## Pretrained best checkpoints

Per-env best (IDM-tuned) 1M checkpoints live in:

```
checkpoints/1m_env_best/{label}_{env_short}/
  checkpoints/{actor,critic,dynamics}/params_1000000.pkl
  config_used.yaml
  flags.json
```

`train_actor_spi.py` resolves the right folder from `--env_name` using
`checkpoints/1m_env_best/manifest.yaml` (accepts the full name `cube-triple-play-v0`
or the short token `cube-triple`). Override with `--pretrained_ckpt_dir`.

## Frozen modules

These are loaded from the checkpoint and never updated:

- dynamics / bridge / subgoal generator
- IDM / inverse dynamics
- value / critic / Q / V / **target** critic
- (any representation encoder embedded in the above networks)

Only the **actor** (`DeterministicChunkActor`) is trained.

## SPI loss

Implemented in `agents/actor.ActorAgent.actor_loss` (deterministic action-chunk actor):

```
L = E[ -Q(s, a_actor, g) / (mean|Q| + eps)
       + (1 / (2 * spi_tau)) * sum_k rho_k * || a_actor - a_prop_k ||^2 ]
```

- `Q` = frozen TRL critic score (`critic_agent.score_action_chunks`, read-only params).
- `a_prop_k` = frozen dynamics/IDM proposal action chunks; `rho` = softmax over their
  critic scores (the soft IDM reference policy).
- `D` = squared L2 distance to the reference chunk (matches the deterministic actor geometry).
- `spi_tau`: **smaller → stick closer to the IDM reference; larger → follow critic
  improvement more strongly.**

Subgoal `gap`/`alpha`/value-bonus options are taken from the checkpoint and not modified.

## Run a single tau

```bash
MUJOCO_GL=egl python train_actor_spi.py \
  --env_name=cube-triple-play-v0 \
  --seed=0 \
  --spi_tau=1.0 \
  --actor_spi_steps=50000 \
  --actor_spi_lr=3e-4
```

Optionally drive defaults from a YAML (CLI still wins):

```bash
MUJOCO_GL=egl python train_actor_spi.py \
  --env_name=cube-triple-play-v0 --spi_tau=1.0 \
  --actor_spi_config=config/actor_spi/actor_spi_default.yaml
```

## Sweep tau

```bash
bash scripts/sweep_actor_spi_tau.sh puzzle-3x3 0
bash scripts/sweep_actor_spi_tau.sh cube-double 0
bash scripts/sweep_actor_spi_tau.sh antmaze-large 0
# custom tau list:
bash scripts/sweep_actor_spi_tau.sh cube-double 0 0.1 1.0 10.0
```

Default tau list: `0.01 0.03 0.1 0.3 1.0 3.0 10.0`.
Env vars: `GPU_ID`, `ACTOR_SPI_STEPS`, `ACTOR_SPI_LR`, `ACTOR_SPI_BATCH_SIZE`,
`EVAL_INTERVAL`, `SAVE_INTERVAL`, `EVAL_EPISODES`, `PRETRAINED_CKPT_DIR`.

## Smoke test / debug

Runs only N steps and forces the freeze/trained param-diff assertions:

```bash
MUJOCO_GL=egl python train_actor_spi.py \
  --env_name=cube-double-play-v0 --debug_num_steps=2
```

Checks: checkpoint loads, 1+ actor SPI updates succeed, actor params change,
critic/IDM/dynamics params do **not** change, and `_evaluate_env_tasks` is callable.

## Output layout

Results never overwrite the best checkpoints. Per tau/seed:

```
checkpoints/actor_spi/{env_name}/tau_{spi_tau}/seed_{seed}/
  checkpoints/actor/params_{step}.pkl   # finetuned actor only
  eval_results/epoch{step}_*.json       # actor SPI eval (reuses main eval)
  flags.json                            # copied from the pretrained run (frozen-module configs)
  config_used.yaml                      # copied pretrained config
  train.csv                             # actor SPI training metrics
  actor_spi_meta.yaml                   # tau, seed, pretrained dir, param-diff, final eval
```

For external re-eval, the frozen dynamics/critic come from `pretrained_ckpt_dir`
(recorded in `actor_spi_meta.yaml`); the finetuned actor is in this tau dir.

## Config / flags

| flag | meaning | default |
|---|---|---|
| `--pretrained_ckpt_dir` | pretrained mini-run dir | auto from `--env_name` |
| `--pretrained_epoch` | checkpoint suffix | `-1` (latest) |
| `--actor_spi_steps` | actor SPI gradient steps | `50000` |
| `--actor_spi_lr` | actor Adam LR | `3e-4` |
| `--spi_tau` | SPI tau override (`<0` keeps ckpt) | `-1` |
| `--actor_spi_batch_size` | batch size (`0` = ckpt) | `0` |
| `--eval_interval` | eval every N steps (`0` off) | `0` |
| `--save_interval` | save every N steps (`0` final-only) | `0` |
| `--freeze_non_actor` | freeze all non-actor modules | `True` |
| `--reset_actor_optimizer` | fresh Adam for the actor | `True` |
| `--debug_num_steps` | smoke-test step count (`0` off) | `0` |
| `--actor_spi_eval_episodes` | eval episodes per task | `25` |

Logged metrics: `actor_spi/loss`, `actor_spi/q_term`, `actor_spi/prox_term`,
`actor_spi/spi_tau`, `actor_spi/actor_action_norm`, `actor_spi/idm_action_norm`,
`actor_spi/action_l2_to_idm`, plus eval success rates.
