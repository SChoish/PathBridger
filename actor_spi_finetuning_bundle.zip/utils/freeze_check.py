"""Helpers to verify that frozen modules stay unchanged during actor SPI finetuning.

Used by ``train_actor_spi.py`` to assert that only the actor parameters move while
dynamics / IDM / subgoal / critic (and any target nets) remain numerically identical.
"""

from __future__ import annotations

from typing import Any

import jax
import numpy as np


def _leaves(tree: Any) -> list[np.ndarray]:
    return [np.asarray(x) for x in jax.tree_util.tree_leaves(tree)]


def tree_max_abs_diff(before: Any, after: Any) -> float:
    """Max absolute element-wise difference across all leaves of two pytrees."""
    bs = _leaves(before)
    as_ = _leaves(after)
    if len(bs) != len(as_):
        raise ValueError(f'pytree leaf count mismatch: {len(bs)} vs {len(as_)}')
    worst = 0.0
    for b, a in zip(bs, as_):
        if b.shape != a.shape:
            raise ValueError(f'leaf shape mismatch: {b.shape} vs {a.shape}')
        if b.size == 0:
            continue
        worst = max(worst, float(np.max(np.abs(a - b))))
    return worst


def summarize_param_diff(before: Any, after: Any) -> dict[str, float]:
    """Return ``max_abs`` / ``mean_abs`` / ``num_changed_leaves`` between two pytrees."""
    bs = _leaves(before)
    as_ = _leaves(after)
    if len(bs) != len(as_):
        raise ValueError(f'pytree leaf count mismatch: {len(bs)} vs {len(as_)}')
    max_abs = 0.0
    sum_abs = 0.0
    count = 0
    num_changed = 0
    for b, a in zip(bs, as_):
        if b.size == 0:
            continue
        d = np.abs(a - b)
        max_abs = max(max_abs, float(np.max(d)))
        sum_abs += float(np.sum(d))
        count += int(d.size)
        if float(np.max(d)) > 0.0:
            num_changed += 1
    return {
        'max_abs': max_abs,
        'mean_abs': (sum_abs / count) if count else 0.0,
        'num_changed_leaves': float(num_changed),
        'num_leaves': float(len([b for b in bs if b.size > 0])),
    }


def assert_frozen(before: Any, after: Any, *, name: str, tol: float = 1e-6) -> dict[str, float]:
    """Raise if a frozen module's params moved beyond ``tol``; returns the diff summary."""
    summary = summarize_param_diff(before, after)
    if summary['max_abs'] > float(tol):
        raise RuntimeError(
            f'[freeze_check] {name} params changed (max_abs={summary["max_abs"]:.3e} > tol={tol:.1e}); '
            'frozen module was unexpectedly updated.'
        )
    return summary


def assert_trained(before: Any, after: Any, *, name: str, min_abs: float = 0.0) -> dict[str, float]:
    """Raise if a trainable module's params did NOT move (> ``min_abs``); returns the diff summary."""
    summary = summarize_param_diff(before, after)
    if summary['max_abs'] <= float(min_abs):
        raise RuntimeError(
            f'[freeze_check] {name} params did not change (max_abs={summary["max_abs"]:.3e}); '
            'expected the trainable module to be updated.'
        )
    return summary
